package co.com.bcs.redebanclient.controller.v1.entity;

public enum Franquicia {

  MASTERCARD , VISA

}
