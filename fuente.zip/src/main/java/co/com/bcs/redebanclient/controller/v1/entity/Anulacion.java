package co.com.bcs.redebanclient.controller.v1.entity;

import lombok.Data;

@Data
public class Anulacion extends Compra {
    
  DatosAnulacion datosAnulacion;  


}
