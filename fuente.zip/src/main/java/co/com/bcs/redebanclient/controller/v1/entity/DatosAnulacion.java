package co.com.bcs.redebanclient.controller.v1.entity;

import lombok.Data;

@Data
public class DatosAnulacion {

String numAprobacion;
String idTransaccionAutorizador;
String razonAnulacion;

}
