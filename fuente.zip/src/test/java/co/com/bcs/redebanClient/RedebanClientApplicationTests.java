package co.com.bcs.redebanClient;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class RedebanClientApplicationTests {

	@Test
	void contextLoads() {
	}

}
